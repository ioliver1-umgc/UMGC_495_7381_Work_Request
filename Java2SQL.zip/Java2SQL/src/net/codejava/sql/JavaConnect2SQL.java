package net.codejava.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JavaConnect2SQL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url ="jdbc:sqlserver://localhost;databaseName=Pulse";  //integratedSecurity=true
		String user = "sa";
		String password = "1234567890";
		try {
		Connection connection = DriverManager.getConnection(url,user,password);
				System.out.println("Connect to MS SQL Server. Good Job Dude.");
		} catch (SQLException e) {
			System.out.println("Ooop, there's an error:");
			e.printStackTrace();}
	}

}
